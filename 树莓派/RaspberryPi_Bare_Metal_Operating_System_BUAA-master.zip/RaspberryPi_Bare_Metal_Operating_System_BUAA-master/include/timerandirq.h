#ifndef _TIMERANDIRQ_H_
#define _TIMERANDIRQ_H_
extern void timer_init();
extern void enable_irq();
extern void disable_irq();
#endif